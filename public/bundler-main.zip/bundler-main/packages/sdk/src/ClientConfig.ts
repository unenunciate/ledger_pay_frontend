export interface ClientConfig {
  paymasterAddress?: string
  entryPointAddress: string
  bundlerUrl: string
  chainId: number
}

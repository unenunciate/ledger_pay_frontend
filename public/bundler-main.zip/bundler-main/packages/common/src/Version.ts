// eslint-disable-next-line @typescript-eslint/no-var-requires
export const erc4337RuntimeVersion: string = require('../../package.json').version

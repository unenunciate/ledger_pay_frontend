#!/bin/bash -xe
#echo postpack for "contracts" package
cd `dirname $0`/..
pwd
rm -rf contracts/artifacts contracts/types contracts/dist

